#Basic widgets and Layout Widgets
Group 13
In the context of the safemove project.
