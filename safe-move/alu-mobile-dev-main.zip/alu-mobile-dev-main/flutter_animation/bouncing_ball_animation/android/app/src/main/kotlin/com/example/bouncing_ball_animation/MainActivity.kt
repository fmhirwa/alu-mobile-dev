package com.example.bouncing_ball_animation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
