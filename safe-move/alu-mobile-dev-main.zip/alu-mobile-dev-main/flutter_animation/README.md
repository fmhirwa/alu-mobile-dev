# Flutter animation
Link to demo: https://youtu.be/vngDe24J4CE