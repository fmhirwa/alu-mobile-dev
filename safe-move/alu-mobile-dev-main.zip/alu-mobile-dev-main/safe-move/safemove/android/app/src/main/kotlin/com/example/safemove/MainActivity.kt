package com.example.safemove

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
